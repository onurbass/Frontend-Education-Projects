import "./App.css";

import Film from "./pages";

function App() {
  return (
    <>
      <div className="App">
        <Film />
      </div>
    </>
  );
}

export default App;
