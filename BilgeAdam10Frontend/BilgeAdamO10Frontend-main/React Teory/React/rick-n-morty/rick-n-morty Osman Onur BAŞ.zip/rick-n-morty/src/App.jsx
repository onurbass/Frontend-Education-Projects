import "./App.scss";
import Character from "./pages/Character/Chararcter.jsx";

function App() {
  return (
    <div className="App">
      <Character />
    </div>
  );
}

export default App;
